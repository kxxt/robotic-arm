echo "Tip: must be sourced under root directory of the repo!"
export PYTHONPATH=$(pwd):${PYTHONPATH}
